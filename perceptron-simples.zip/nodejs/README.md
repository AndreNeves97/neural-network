Nome: André Marcelino de Souza Neves

# Trabalho de algoritmos genéticos

- Contém a implementação do perceptrom simples para as bases
  - Controle de robô
  - Porta AND
  - Porta OR
  - Porta XOR




# Execução:

- Necessário ter instalado no ambiente:
  - Node.js
  - Yarn
  - NPM


- Executar:
  - `yarn install` 
    - Atualizar dependências
  - `yarn start {type}` 
    - Executar aplicação
    - `{type}` refere-se à qual base será treinada, que pode ser:
      - robot
      - and
      - or
      - xor